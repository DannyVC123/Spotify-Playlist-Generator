import json

from chatgpt_client import ChatGPTClient
from spotify_client import SpotifyClient

# generate ai playlist
def lambda_handler(event, context):
    try:
        headers = event['headers']
        chatgpt_client, spotify_client = initialize_clients(headers)

        body = event['body']

        user_prompt = body['user_prompt']
        playlist_name = body['playlist_name']
        limit = body['limit']
        public = body['public']

        return generate_playlist(chatgpt_client, spotify_client,
                                 user_prompt, playlist_name, limit, public)
    except:
        response = {
            "statusCode": 500,
            "message": "Generate Playlist Failed."
        }
        return json.dumps(response)

def initialize_clients(headers):
    chat_gpt_api_key = headers['gpt_authorization']
    spotify_api_key = headers['spotify_authorization']

    chatgpt_client = ChatGPTClient(chat_gpt_api_key)
    spotify_client = SpotifyClient(spotify_api_key)

    return (chatgpt_client, spotify_client)

def generate_playlist(chatgpt_client, spotify_client, user_prompt, playlist_name, limit=10, public=False):
    tracks_json = chatgpt_client.get_recommendations_json(user_prompt, limit)

    tracks = spotify_client.get_all_tracks(tracks_json, limit)
    if not tracks:
        return error_json('Get Tracks Failed.')

    playlist = spotify_client.create_playlist(playlist_name, public=public)
    if not playlist:
        return error_json('Create Playlist Failed.')
    
    playlist_url = spotify_client.populate_playlist(playlist, tracks)
    if not playlist_url:
        return error_json('Populate Playlist Failed.')
    
    response = {
        "statusCode": 200,
        "message": "Playlist generated successfully.",
        "data": {
            "tracks": [track.to_dict() for track in tracks],
            "playlist_url": playlist_url
        }
    }
    return json.dumps(response)

def error_json(message):
    response = {
        "statusCode": 500,
        "message": message
    }
    return json.dumps(response)