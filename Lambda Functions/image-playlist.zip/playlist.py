class Playlist:
    def __init__(self, id, name, num_songs):
        self.id = id
        self.name = name
        self.num_songs = num_songs